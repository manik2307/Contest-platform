package com.crio.codingame.exceptions;

public class InvalidContestException extends RuntimeException{
    public InvalidContestException()
 {
  super();
 }
 public InvalidContestException(String msg)
 {
  super(msg);
 }
}
