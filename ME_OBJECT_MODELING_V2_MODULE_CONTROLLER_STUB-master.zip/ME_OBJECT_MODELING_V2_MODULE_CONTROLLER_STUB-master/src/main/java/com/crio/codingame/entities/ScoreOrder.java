package com.crio.codingame.entities;

public enum ScoreOrder {
    ASC,DESC
}
