package com.crio.codingame.entities;

public abstract class BaseEntity {
    protected String id;

    public String getId() {
        return id;
    }
    
}

