
package com.crio.codingame.entities;

public enum ContestStatus {
    NOT_STARTED ,IN_PROGRESS, ENDED
}

